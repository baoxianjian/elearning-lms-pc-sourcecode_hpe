package org.apache.lucene.analysis.ik2;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;



import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.lucene.util.AttributeFactory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;

/** 
 * IK分词器 Lucene Tokenizer适配器类 
 * 兼容Lucene 4.0版本 
 */  
public final class IKTokenizer extends Tokenizer {  
      
    //IK分词器实现  
    private IKSegmenter _IKImplement;  
    
    ArrayList<Lexeme> singleWords = new ArrayList();
    HashMap<String,Object> singleWordKeys=new HashMap();
    
      
    //词元文本属性  
    private final CharTermAttribute termAtt; 
    //词元位移属性  
    private final OffsetAttribute offsetAtt;  
    //词元分类属性（该属性分类参考org.wltea.analyzer.core.Lexeme中的分类常量）  
    private final TypeAttribute typeAtt;  
    //记录最后一个词元的结束位置  
    private int endPosition;  
      
    private Version version = Version.LATEST;  
    
    private boolean keepSingleWord=true;
    
    private boolean splitToSingleWords=true;
    
    private boolean onlySingleWords=false;
    
    /** 
     * Lucene 4.0 Tokenizer适配器类构造函数 
     * @param in 
     * @param useSmart 
     */  
    
    public IKTokenizer(Reader in , boolean useSmart){  
        //super(in);  
        offsetAtt = addAttribute(OffsetAttribute.class);  
        termAtt = addAttribute(CharTermAttribute.class);  
        typeAtt = addAttribute(TypeAttribute.class);  
        _IKImplement = new IKSegmenter(input , useSmart);  
    } 
    
      
    public IKTokenizer(AttributeFactory factory, boolean useSmart) {  
        super(factory);  
        offsetAtt = addAttribute(OffsetAttribute.class);  
        termAtt = addAttribute(CharTermAttribute.class);  
        typeAtt = addAttribute(TypeAttribute.class);  
        _IKImplement = new IKSegmenter(input , useSmart);  
    }
    
    public IKTokenizer(AttributeFactory factory, boolean useSmart, boolean keepSingleWord)
    { 
    	this(factory, useSmart);
    	this.keepSingleWord = keepSingleWord;
    }
    
    public IKTokenizer(AttributeFactory factory, boolean useSmart, boolean keepSingleWord, boolean splitToSingleWords)
    { 
    	this(factory, useSmart,keepSingleWord);
    	this.splitToSingleWords=splitToSingleWords;
    }
    
    public IKTokenizer(AttributeFactory factory, boolean useSmart, boolean keepSingleWord, boolean splitToSingleWords,boolean onlySingleWords)
    { 
    	this(factory, useSmart,keepSingleWord,splitToSingleWords);
    	this.onlySingleWords=onlySingleWords;
    	if(this.onlySingleWords)
    	{
    		this.splitToSingleWords=true;
    	}
    }
    
  
    /* (non-Javadoc) 
     * @see org.apache.lucene.analysis.TokenStream#incrementToken() 
     */  
    @Override  
    public boolean incrementToken() throws IOException {  
        //清除所有的词元属性  
        clearAttributes();  
        Lexeme nextLexeme = _IKImplement.next();  
        
        if(nextLexeme != null){  
            //将Lexeme转成Attributes  
            //设置词元文本  
        	
        	String str=nextLexeme.getLexemeText();
        	
        	
        	
        	if(!this.keepSingleWord && str.length()<2)
        	{
        		return this.incrementToken();
        	}
        	
        
        	//只有中文词才分割
        	if(this.splitToSingleWords && nextLexeme.getLexemeType()==nextLexeme.TYPE_CNWORD)
        	{
        		//(int offset, int begin, int length, int lexemeType);
        		Lexeme lexeme = null;
        		String singleWrod=null;
        		int length=str.length();
        		for(int i=0;i<length;i++)
        		{
        			lexeme = new Lexeme(nextLexeme.getOffset(),nextLexeme.getBeginPosition()+i,1,nextLexeme.TYPE_CNCHAR);
        			
        			singleWrod=str.charAt(i)+"";
        			
        			lexeme.setLexemeText(singleWrod);
        			
        			if(!singleWordKeys.containsKey(singleWrod))
        			{
        				singleWords.add(lexeme);
        				singleWordKeys.put(singleWrod, null);
        			}
        		}
        		if(this.onlySingleWords)
        		{
        			return this.incrementToken();
        		}
        	}
        	else
        	{
	    		if(this.onlySingleWords)
	    		{	
	    			//return this.incrementToken();
					singleWords.add(nextLexeme);
					singleWordKeys.put(str, null);
					return this.incrementToken();
	    		}
        	}
        	
        	
            termAtt.append(str);  
            //设置词元长度  
            termAtt.setLength(nextLexeme.getLength());  
            //设置词元位移  
            offsetAtt.setOffset(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition());  
            //记录分词的最后位置  
            endPosition = nextLexeme.getEndPosition();  
            //记录词元分类  
            typeAtt.setType(nextLexeme.getLexemeTypeString());            
            //返会true告知还有下个词元  
            return true;  
         
        }
        
        int length=singleWords.size();
        
        for(int i=0;i<length;i++)
        {
        	nextLexeme = singleWords.get(i);
        	if(nextLexeme!=null)
        	{
        		singleWords.remove(i);
        		break;
        	}
        }
        
        if(nextLexeme != null)
        {  
	        termAtt.append(nextLexeme.getLexemeText());  
	        //设置词元长度  
	        termAtt.setLength(nextLexeme.getLength());  
	        //设置词元位移  
	        offsetAtt.setOffset(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition());  
	        //记录分词的最后位置  
	        endPosition = nextLexeme.getEndPosition();  
	        //记录词元分类  
	        typeAtt.setType(nextLexeme.getLexemeTypeString());            
	        //返会true告知还有下个词元  
	        return true;  
        }
        
        singleWords.clear();
        singleWordKeys.clear();
        
        //返会false告知词元输出完毕  
        return false;  
    }  
      
    /* 
     * (non-Javadoc) 
     * @see org.apache.lucene.analysis.Tokenizer#reset(java.io.Reader) 
     */  
    @Override  
    public void reset() throws IOException {  
        super.reset();  
        _IKImplement.reset(input);  
    }     
      
    @Override  
    public final void end() {  
        // set final offset  
        int finalOffset = correctOffset(this.endPosition);  
        offsetAtt.setOffset(finalOffset, finalOffset);  
    }
}