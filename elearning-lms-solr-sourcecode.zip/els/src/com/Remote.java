package com;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import dao.Config;

public class Remote {

	public static String CHARSET_UTF8 = "utf-8";

	private static boolean isTrim;
	
	static
	{
		isTrim=Config.getBoolean("html.trim");
	}
	
	/**
	 * Get Request
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String doGet(String url, boolean isTrim, boolean isReplaceIncludeTag) {

		InputStream inputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader reader = null;
		StringBuffer resultBuffer = null;

		try {

			URL localURL = new URL(url);

			URLConnection connection = localURL.openConnection();
			HttpURLConnection httpURLConnection = (HttpURLConnection) connection;

			httpURLConnection.setRequestProperty("Accept-Charset", "utf-8");
			httpURLConnection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");

			// Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101
			// Firefox/30.0

			httpURLConnection.setRequestProperty("Host", localURL.getHost());
			// httpURLConnection.setRequestProperty("User-Agent",
			// "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:36.0) Gecko/20100101 Firefox/36.0");
			// httpURLConnection.setRequestProperty("User-Agent",
			// "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0");

			httpURLConnection.setRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C; .NET4.0E; InfoPath.2)");

			// httpURLConnection.setRequestProperty("Accept",
			// "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			// httpURLConnection.setRequestProperty("Accept-Language",
			// "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
			// httpURLConnection.setRequestProperty("Accept-Encoding",
			// "gzip, deflate");
			// httpURLConnection.setRequestProperty("DNT", "1");
			// httpURLConnection.setRequestProperty("Cookie",
			// "3156_pid211629=211629; __web_im_user=14990825; __web_im_ip=113.204.112.138; __web_im_location=%E6%9C%AA%E7%9F%A5-%E6%9C%AA%E7%9F%A5; cck_lasttime=1427729630842; cck_count=0; Hm_lvt_4098f5dc8ed17043633a9800513e54f8=1427729632; Hm_lpvt_4098f5dc8ed17043633a9800513e54f8=1427729632; bdshare_firstime=1427729631992");
			// httpURLConnection.setRequestProperty("Connection", "keep-alive");
			// httpURLConnection.setRequestProperty("Cache-Control",
			// "max-age=0");

			// httpURLConnection.setRequestProperty("contentType", "UTF-8");

			if (httpURLConnection.getResponseCode() >= 300) {
				// throw new
				// Exception("HTTP Request is not success, Response code is " +
				// httpURLConnection.getResponseCode());
				String code =  httpURLConnection.getResponseCode()+"";
				System.out.println("HTTP Request error:" + url + ", code:"+ code);
				return code;
			}

			String tempLine = null;
			resultBuffer = new StringBuffer();

			inputStream = httpURLConnection.getInputStream();

			
			/*
			  System.out.println( httpURLConnection.getResponseMessage());
			  System.out.println(httpURLConnection.getHeaderField(1));
			  
			  int i=0; 
			  int a=0;
			  while ((a = inputStream.read()) != -1) 
			  {
				  if(i>=100) { break; } 
				  System.out.print(a+" "); 
				  i++; 
			  }
			  //inputStream.close(); 
			  //System.exit(0);
			*/
			
			
			
			/*
			 * byte[] bytes=new byte[inputStream.available()]; int len=
			 * inputStream.read(bytes);
			 * //返回的len是保存到bytes数组中实际的长度，比如说bytes数组定义长度为1024
			 * ，但是只读取了100个字节长度，那么则返回的len为100，len最大值为bytes数组初始长度
			 * 
			 * tempLine=new String(bytes,"utf-8");
			 */

			// inputStreamReader = new
			// InputStreamReader(inputStream,CHARSET_UTF8);
			inputStreamReader = new InputStreamReader(inputStream, CHARSET_UTF8);

			reader = new BufferedReader(inputStreamReader);

			// ȥbom
			tempLine = reader.readLine();
			if (tempLine != null && tempLine.length() > 0) {
				if ((int) tempLine.charAt(0) == 65279) {
					tempLine = tempLine.substring(1);
				}
				resultBuffer.append(tempLine + "\r\n");
			}

			while ((tempLine = reader.readLine()) != null) {
				resultBuffer.append(tempLine + "\r\n");
			}

		} catch (Exception e) {
			//e.printStackTrace();
		}

		finally {
			try {
				if (reader != null) {
					reader.close();
				}
				if (inputStreamReader != null) {
					inputStreamReader.close();
				}
				if (inputStream != null) {
					inputStream.close();
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}

		}
		
		if(resultBuffer==null)
		{
			System.out.println("HTTP Request error:" + url + ", code:404");
			return "404";
		}
		
		String html = resultBuffer.toString();
		if(isTrim)
		{
			html = htmlTrim(html);
		}
		if(isReplaceIncludeTag)
		{
			html = replaceIncludeTag(html);
		}
		return html;
	}
	
	public static String doGet(String url,boolean isTrim)
	{
		return doGet(url, isTrim, true);
	}
	
	public static String doGet(String url)
	{
		return doGet(url,isTrim,true);
	}
	
	public static String htmlTrim(String html)
	{
		if(html == null){return "";}
		html=html.replaceAll("(\t)+", " ");
		html=html.replaceAll("( )+", " ");
		html=html.replaceAll("(\r\n )+", "\r\n");
		return html;
	}

	public static String replaceIncludeTag(String html)
	{
		return html=html.replaceAll("(<!--x#include )+", "<!--#include ");
	}
}
