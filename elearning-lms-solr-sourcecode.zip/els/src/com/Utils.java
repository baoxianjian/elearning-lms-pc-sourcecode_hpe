package com;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.Calendar;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;


/**只需要在project build path中先移除JRE System Library，再添加库JRE System Library，重新编译后就一切正常了。 */
import sun.misc.BASE64Encoder;

public class Utils {
	
	public static final String exeCute(String cmds)
	{
		InputStream in;
		String line = null;
		StringBuffer sb = null;
		try
		{
			in = Runtime.getRuntime().exec(cmds).getInputStream();
			BufferedReader b = new BufferedReader(new InputStreamReader(in));
			
			sb = new StringBuffer();
			while ((line = b.readLine()) != null) 
			{
				sb.append(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	public static final boolean checkPidInProcess(String pid){
		//String[] cmds = {"/bin/ln", "-s", "/var/www/xxx/blocks","/var/www/3156/blocks"};
		//String cmds="/bin/ln -s /var/www/xxx/blocks /var/www/3156/blocks9";
		System.out.println(Utils.exeCute("jps"));
		return false;
	}

	public static final String getProcessID() {
		RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
		return runtimeMXBean.getName().split("@")[0];
	}
	
	
    public static String base64Encode(String str) {
        try {
            return new String(Base64.encodeBase64(str.getBytes()), "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }
     
    /**
     * 灏咮ASE64瀛楃涓叉仮澶嶄负浜岃繘鍒舵暟鎹�
     * @param base64String
     * @return
     */
    public static byte[] base64Decode(String str) {
        try {
            return Base64.decodeBase64(str.getBytes("UTF-8"));
        } catch (Exception e) {
            return null;
        }
    }
    
    public static Boolean isNight()
    {
		int hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		if(hour >0 && hour<8) //1鐐瑰埌7鐐�
		{
			return true;
		}
		
    	return false;
    }
    
    public static String trim(String str)
    {
    	if(str==null){return "";}
    	return str.replaceAll("[\r\n\t ]", "");
    }
    
    public static String html2Text(String inputString) {      
        String htmlStr = inputString; // 含html标签的字符串      
        String textStr = "";      
        java.util.regex.Pattern p_script;      
        java.util.regex.Matcher m_script;      
        java.util.regex.Pattern p_style;      
        java.util.regex.Matcher m_style;      
        java.util.regex.Pattern p_html;      
        java.util.regex.Matcher m_html;      
    
        java.util.regex.Pattern p_html1;      
        java.util.regex.Matcher m_html1;      
    
       try {      
            String regEx_script = "<[//s]*?script[^>]*?>[//s//S]*?<[//s]*?///[//s]*?script[//s]*?>"; // 定义script的正则表达式{或<script[^>]*?>[//s//S]*?<///script>      
            String regEx_style = "<[//s]*?style[^>]*?>[//s//S]*?<[//s]*?///[//s]*?style[//s]*?>"; // 定义style的正则表达式{或<style[^>]*?>[//s//S]*?<///style>      
            String regEx_html = "<[^>]+>"; // 定义HTML标签的正则表达式      
            String regEx_html1 = "<[^>]+";      
            p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);      
            m_script = p_script.matcher(htmlStr);      
            htmlStr = m_script.replaceAll(""); // 过滤script标签      
    
            p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);      
            m_style = p_style.matcher(htmlStr);      
            htmlStr = m_style.replaceAll(""); // 过滤style标签      
    
            p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);      
            m_html = p_html.matcher(htmlStr);      
            htmlStr = m_html.replaceAll(""); // 过滤html标签      
    
            p_html1 = Pattern.compile(regEx_html1, Pattern.CASE_INSENSITIVE);      
            m_html1 = p_html1.matcher(htmlStr);      
            htmlStr = m_html1.replaceAll(""); // 过滤html标签      
    
            textStr = htmlStr;      
    
        } catch (Exception e) {      
            System.err.println("Html2Text: " + e.getMessage());      
        }      
    
       return textStr;// 返回文本字符串      
    }     

    
}
