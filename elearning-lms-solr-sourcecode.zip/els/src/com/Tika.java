package com;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.tika.detect.EncodingDetector;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.txt.Icu4jEncodingDetector;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.sax.ContentHandlerDecorator;
import org.apache.tika.sax.ToXMLContentHandler;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import dao.Config;

public class Tika 
{
	//String 
	private static String parseToHTML(File file)
	{
		ContentHandler handler = new ToXMLContentHandler();
		AutoDetectParser parser = new AutoDetectParser();
		Metadata metadata = new Metadata();
		ParseContext context = new ParseContext();


			//InputStream stream = Test.class.getResourceAsStream("计算机软件毕业设计论文(范文).doc");
			//File f = new File("c:/docs");
			//System.out.println(file);

			try {
				
				InputStream stream =  new FileInputStream(file);
				parser.parse(stream, handler, metadata, context);

				return handler.toString();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				/*
				htmlText=htmlText.replaceAll("<!--", "&lt;!11");
				htmlText=htmlText.replaceAll("-->", "11&gt;");
				htmlText=htmlText.replaceAll("--", "————");
				htmlText=htmlText.replaceAll("&lt;!11","<!--");
				htmlText=htmlText.replaceAll("11&gt;","<!--");
				*/
				//e.printStackTrace();
				System.out.println(e.getMessage());
			}

				
			/*
			 * String [] names=metadata.names(); for(int i=0;i<names.length;i++)
			 * { System.out.println(names[i]+":"+metadata.get(names[i])); }
			 */

			// System.out.println(context.));

			return null;

	}

	private static String getEncoding(File file)
	{
		InputStream stream=null;
		try {
			stream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //HtmlEncodingDetector  UniversalEncodingDetector  Icu4jEncodingDetector  
        EncodingDetector encodingDetector=new Icu4jEncodingDetector();  
        Charset encode=null;
		try {
			encode = encodingDetector.detect(new BufferedInputStream(stream), new Metadata());
			return encode.name();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		return null;
	}
	
	private static HashMap<String, String> htmlParseToKV(File file)
	{
		String encoding=getEncoding(file);
		Document doc=null;
		try {
			doc = Jsoup.parse(file,encoding);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return htmlParseToKV(doc);
	}
	
	private static HashMap<String, String> htmlParseToKV(String htmlText)
	{
		Document doc = Jsoup.parse(htmlText);
		return htmlParseToKV(doc);

	}
	
	private static HashMap<String, String> htmlParseToKV(Document document)
	{
		if(document==null)
		{
			return null;
		}
		
		/*
		// 获取根节点元素对象
		Element root = document.getRootElement();

		HashMap<String, String> hm = new HashMap();
		String title= root.element("head").elementText("title");
		String content= root.element("body").getStringValue();
		
		System.out.println(root.elementText("body"));
		*/

		HashMap<String, String> hm = new HashMap();
		String title= document.title();
		String content= null;
		if(document.body()!=null)
		{
			content=document.body().text();
			content=Utils.html2Text(content);
		}
		hm.put("title",Utils.trim(title));
		hm.put("content",Utils.trim(content));
		
		System.out.println(hm.get("content"));
		

		//System.out.println(metadata.toString());
		 System.out.println("标题:"+hm.get("title"));
		// System.out.println("内容:"+hm.get("content"));
		
		
		return hm;
	}
	
	public static HashMap<String, String> ParseToKV(File file)
	{
		System.out.println(file);
		//本身为xml或html
		if("html,htm,shtml,xml".indexOf(getFileExtention(file.getName()))>-1)
		{
			
			 return htmlParseToKV(file);
		}
		
		return htmlParseToKV(parseToHTML(file));
	}
	
	
	
	
	
	// 递归
	private static void parseFile(File file,ArrayList<HashMap> al)
	{
		if(!file.exists() || !file.canRead())
		{
			return;
		}
		//if(getFileExtention(file.getName()))
		
		try {
			if(file.isDirectory())
			{
				String[] files = file.list();
				if (files != null) {
					for (int i = 0; i < files.length; i++) 
					{
						parseFile(new File(file, files[i]),al);
					}
				}
			}
			else
			{/*
				// if (file.getName().endsWith("ppt"))
				//不在指定文件扩展名内
				if(Config.get("file.parse.types").indexOf(getFileExtention(file.getName()))<0)
				{
					return;
				}
					*/
				
				if("txt,html,htm,pdf,doc,docx,ppt,pptx,xls,xlsx,xml,mp4,swf,flv,mp3,jpg".indexOf(getFileExtention(file.getName()))<0)
				{
					return;
				}
			
				HashMap hm=ParseToKV(file);
				if(hm!=null)
				{
					al.add(hm);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static ArrayList parseFile(String filePath)
	{
		System.out.println(filePath);
		ArrayList<HashMap> al = new ArrayList();
		File file = new File(filePath);
		parseFile(file,al);
		return al;
	}

	
	public static String getFileExtention (String fileName)
	{
		int pointIndex=fileName.indexOf('.');
		if(pointIndex<0)
		{
			return "";
		}
		return fileName.substring(pointIndex+1);
		
	}

	public static void main(String[] args)
	{
		Tika t = new Tika();
		//String path="E:\\z_upload\\upload\\filedir\\4d\\4dbc57a627a70d57c455d8da14ec2364\\SCOs\\sco1\\player.html";

		String path="E:\\z_upload\\upload\\filedir\\2b\\2bc4156c61e50f3eb16498b06029e47d\\pub\\course.xml";
		//path="E:/z_upload/upload/originfile/b0";
		path="E:\\z_upload\\upload\\filedir\\04\\04c6b442efc19decde2790e4b652f218\\res\\data\\presentation.xml";
		
	
		ArrayList al =t.parseFile(path);
		//System.out.println(al.size());
		//
		//

	}


}
