package com;

import tasks.*;
import it.sauronsoftware.junique.AlreadyLockedException;
import it.sauronsoftware.junique.JUnique;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import com.mysql.fabric.xmlrpc.base.Data;

import dao.DAO;
import dao.SolrConfig;

public class Start {
    private static Properties props = new Properties(); 
    
    
    
    

	public static void main(String[] args) throws Exception
	{
		//System.out.println(Math.pow(268000, 0.75));
		
		//int i = Calendar.get(Calendar.HOUR_OF_DAY); 
		
		checkStart(args);
	
		/*
		WJCQGX t1 = new WJCQGX();
		t1.setImportType(t1.IMPORT_TYPE_FULL);
		t1.run();
		*/

        //文件抽取更新 on
        Timer timer1 = new Timer(); 
        WJCQGX t1 = new WJCQGX();
        t1.setImportType(t1.IMPORT_TYPE_DELTA);
        timer1.schedule(t1, 1,SolrConfig.getUpdatePeriod()*1000);		
		
		/*
        //sorl更新 on
        Timer timer100 = new Timer();  
        SOLRGX t100 = new SOLRGX();
        //t7.run();
        timer100.schedule(t100, 10,SolrConfig.getUpdatePeriod()*1000);
		*/
	}


	
	private static void checkStart(String[] args)
	{
		/*
		String id = Start.class.getName();
		boolean start;
		try {
			JUnique.acquireLock(id, null);
			start = true;
		} catch (AlreadyLockedException e) {
			// Application already running.
			start = false;
			e.printStackTrace();
		}
		if (!start) {
			System.out.println("this java program has been already running");
			//System.exit(0);
		}
		*/
		
		if(args.length>0)
		{
			
			System.setProperty("config.dir", args[0]);
			//System.setProperty("config.dir", "D:\\workspace\\java\\static2");
		}
		else
		{
			System.setProperty("config.dir", ".");
		}
	}
}




