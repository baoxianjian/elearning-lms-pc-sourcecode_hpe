package com;

import dao.DAO;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log {
	

	
	public static void add(String str,int level)
	{
		Log.add(str);
		if(level==1)
		{
			//insert to log
		}
	}
	
	public static void add(String str)
	{
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		System.out.println("["+df.format(new Date())+"]"+str);
	}
}
