package dao;


import java.sql.*;  
import java.util.*;  
public class SqlHelper {  
     
	Connection ct=null;
    static{  
        try {  
            Class.forName("com.mysql.jdbc.Driver");  
        } catch (ClassNotFoundException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
    }

    
    private Connection getConnection(){  
    	if(ct==null)
    	{
	        try {  
                return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/3156db","root","123456");
	        	//return DriverManager.getConnection("jdbc:mysql://211.147.6.220:31306/3156db","7npNaKbG","RvBGIvdcdFZx4248");
	        	//return DriverManager.getConnection("jdbc:mysql://127.0.0.1:31306/3156db","7npNaKbG","RvBGIvdcdFZx4248");
	        } catch (SQLException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	            return null;  
	        }  
    	}
    	else
    	{
    		return ct;
    	}
    }  
    public static void close(ResultSet rs,PreparedStatement ps,Connection ct){  
        try {  
            if(rs!=null)rs.close();  
            if(ps!=null)ps.close();  
            if(ct!=null)ct.close();  
        } catch (Exception e) {  
            // TODO: handle exception  
            e.printStackTrace();  
        }  
    }  
    public ArrayList executeQuery(String sql,String[] arr){  
        Connection ct=null;  
        PreparedStatement ps=null;  
        ResultSet rs=null;  
        try {  
            ct=getConnection();  
            ps=ct.prepareStatement(sql);  
            if(arr!=null&&!arr.equals("")){  
                for(int i=0;i<arr.length;i++){  
                    ps.setString(i+1, arr[i]);  
                }  
            }  
            rs=ps.executeQuery();  
            ArrayList al=new ArrayList();  
            ResultSetMetaData rsmd=rs.getMetaData();  
            int column=rsmd.getColumnCount();  
            while(rs.next()){  
                Object[] ob=new Object[column];  
                for(int i=0;i<ob.length;i++){  
                    ob[i]=rs.getObject(i+1);  
                }  
                al.add(ob);  
            }  
            return al;  
        } catch (Exception e) {  
            // TODO: handle exception  
            e.printStackTrace();  
            return null;  
        }finally{  
           // close(rs,ps,ct);  
        }  
    }  
    public void executeUpdate(String sql,String arr[]){  
        Connection ct=null;  
        PreparedStatement ps=null;  
        ResultSet rs=null;  
        try {  
            ct=getConnection();  
            ps=ct.prepareStatement(sql);  
            if(arr!=null&&!arr.equals("")){  
                for(int i=0;i<arr.length;i++){  
                    ps.setString(i+1, arr[i]);  
                }  
            }  
            ps.executeUpdate();  
        } catch (Exception e) {  
            // TODO: handle exception  
            e.printStackTrace();  
        }  
    }

}  
