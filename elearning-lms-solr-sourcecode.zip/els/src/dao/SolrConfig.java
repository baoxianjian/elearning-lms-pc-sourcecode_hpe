package dao;

import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;



public class SolrConfig 
{
	 static Document document=null;
	 static Element root=null;
	
    static
    {
    	init();
    }
    
    private static void init()
    {
    	SAXReader reader = new SAXReader();
    	
    	String dir = System.getProperty("config.dir");
    	
		File file = new File(dir+"/solr-config.xml");
		  
		try {
			document = reader.read(file);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		root = document.getRootElement();
    }
	
	public static String[] getDeltaImportUrls()
	{
		  String solrUrl=root.elementText("url");

		  List<Element> childElements=root.element("delta-import").elements();
		  
		  String[] list =new String[childElements.size()];
		
		  int i=0;
		  for (Element child : childElements)
		  {
			  list[i]=solrUrl+child.getText();
			  i++;
		  }
		  return list;
	}
    
	
	public static int getThreadInterval()
	{
		return Integer.parseInt(root.elementText("thread-interval"));
	}
	
	public static int getUpdatePeriod()
	{
		return Integer.parseInt(root.element("update").elementText("period"));
	}
	
	public static boolean getUpdateAuto()
	{
    	Connection c = DAO.getConnection();
    	ArrayList<HashMap> al = DAO.executeQuery(c, "SELECT service_status FROM eln_fw_service WHERE service_code='full-text-search'");
    	DAO.closeConnection(c);
    	
    	//数据库优先判断
    	if(al.size()>0)
    	{
    		HashMap hm= al.get(0);
    		if(hm.get("service_status").equals("1"))
    		{
    			return true;
    		}
    		return false;
    	}
    	
    	//再次到配置文件判断
		if(root.element("update").elementText("auto").equals("on"))
		{
			return true;
		}
		return false;
	}
    
	/*
	public static void main(String[] args)
	{
		String[] list=SolrConfig.getDeltaImportUrls();
		for(int i=0;i<list.length;i++)
		{
			System.out.println(list[i]);
		}
	}
	*/
	
	
	
	

}