package dao;
import org.apache.commons.logging.Log; 
import org.apache.commons.logging.LogFactory; 
import org.logicalcobwebs.proxool.ProxoolException; 
import org.logicalcobwebs.proxool.configuration.JAXPConfigurator; 

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException; 
import java.io.IOException; 
import java.io.InputStream;
import java.sql.*; 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List; 
import java.util.Properties; 

/** 
* 简单的JDBC工具类 
* 
*/ 
public class DAO { 
        private static final Log log = LogFactory.getLog(DAO.class); 
        private static final boolean useDBPool = true;    //是否使用数据库连接池 
        private static String dburl = null; 
        private static String user = null; 
        private static String password = null; 
       // private static Properties props = new Properties(); 

        static
        { 
        	init(); 
        }

        public static void init() { 
            if (useDBPool)
            {
            	String dir = System.getProperty("config.dir");
                try
                { 
                    JAXPConfigurator.configure(dir+"/proxool.xml", false); 
//                  JAXPConfigurator.configure("src/proxool.xml", false); 
                } catch (ProxoolException e)
                { 
                	e.printStackTrace(); 
                } 
                return; 
            } 
            
            
            
            /*
            File f = new File("config.properties");  
             
            try {
            	  //InputStream in = DAO.class.getClassLoader().getResourceAsStream("config.properties");
            	InputStream in = new FileInputStream(f);  
				props.load(in);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            dburl = props.getProperty("jdbc.url"); 
            user = props.getProperty("jdbc.username").trim(); 
            password = props.getProperty("jdbc.password").trim();
            */
            dburl = Config.get("jdbc.url");
            user = Config.get("jdbc.username").trim();
            password = Config.get("jdbc.password").trim();
            
            System.out.println(dburl); 
            System.out.println(user); 
            System.out.println(password); 

            //注册驱动类 
            try { 
                    Class.forName(Config.get("jdbc.driver")); 
            } catch (ClassNotFoundException e) { 
                    //log.error("#ERROR# :加载数据库驱动异常，请检查！", e);
            		e.printStackTrace();
                    throw new RuntimeException(e); 
            } 
        } 

/*
        public static void main(String[] args) throws FileNotFoundException { 

                for (int i = 0; i < 5; i++) { 
                        Connection conn = getConnection(); 
                        System.out.println(conn == null ? "没连上" : "连上了"); 
//                        System.out.println("--------"); 
//                closeConnection(conn);                         
                } 

        } 
        */

        /** 
         * 创建一个数据库连接 
         * 
         * @return 一个数据库连接 
         */ 
        public static Connection getConnection(String DBPoolName) { 
                Connection conn = null; 
                //根据连接池配置创建数据库连接 
                if (useDBPool) { 
                        try { 
                                conn = DriverManager.getConnection("proxool."+DBPoolName); 
                        } catch (SQLException e) { 
                                //log.error("#ERROR# :无法从数据库连接池获取到数据库连接！");
                        		e.printStackTrace();
                                throw new RuntimeException(e); 
                        } 
                        return conn; 
                } 
                //根据JDBC配置创建数据库连接 
                try { 
                        conn = DriverManager.getConnection(dburl, user, password); 
                } catch (SQLException e) { 
                        //log.error("#ERROR# :创建数据库连接发生异常，请检查！", e);
                		e.printStackTrace();
                        throw new RuntimeException(e); 
                } 
                return conn; 
        } 

        public static Connection getConnection()
        {
        	return getConnection("DBPool");
        }
        
        /** 
         * 在一个数据库连接上执行一个静态SQL语句查询 
         * 
         * @param conn            数据库连接 
         * @param staticSql 静态SQL语句字符串 
         * @return 返回查询结果集ResultSet对象 
         */ 
        public static ArrayList<HashMap> executeQuery(Connection conn, String staticSql) { 
                ResultSet rs = null; 
                ArrayList<HashMap> al = null;
                try { 
                        //创建执行SQL的对象 
                        Statement stmt = conn.createStatement(); 
                        //执行SQL，并获取返回结果 
                        rs = stmt.executeQuery(staticSql);
                        
                		ResultSetMetaData rsmd = rs.getMetaData();
                		
                		int cCount = rsmd.getColumnCount();
                		String cName = null;
                		
                		al = new ArrayList<HashMap>();
                		HashMap hm = null;
            			while(rs.next()) 
            			{
            				hm = new HashMap();
            	    		for(int i=1;i<=cCount;i++)
            	    		{
            	    			cName = rsmd.getColumnName(i);
            	    			hm.put(cName, rs.getString(cName));
            	    		}
            				al.add(hm);
            			}
                        
                } catch (SQLException e) { 
                        //log.error("#ERROR# :执行SQL语句出错，请检查！\n" + staticSql, e);
                		e.printStackTrace();
                        throw new RuntimeException(e); 
                } 
                return al; 
        } 
        
        /** 
         * 在一个数据库连接上执行一个静态SQL语句 
         * 
         * @param conn            数据库连接 
         * @param staticSql 静态SQL语句字符串 
         */ 
        public static boolean executeSQL(Connection conn, String staticSql) { 
                try { 
                        //创建执行SQL的对象 
                        Statement stmt = conn.createStatement(); 
                        //执行SQL，并获取返回结果 
                        stmt.execute(staticSql);
                        if(stmt.getUpdateCount()>0)
                        {
                        	return true;
                        }
                        return false;
                } catch (SQLException e) { 
                        //log.error("#ERROR# :执行SQL语句出错，请检查！\n" + staticSql, e);
                		e.printStackTrace();
                        //throw new RuntimeException(e);
                		return false;
                }
        } 
        

        /** 
         * 在一个数据库连接上执行一个静态SQL语句 
         * 
         * @param conn            数据库连接 
         * @param Sql SQL语句字符串 
         * @param args 参数列表
         */ 
        public static boolean executeSQL(Connection conn, String sql,String[] args)
        { 
        	try { 
        			PreparedStatement stmt=conn.prepareStatement(sql);
                	for(int i=0;i<args.length;i++)
                	{
                		stmt.setString(i+1, args[i]);
            		}
                    //执行SQL，并获取返回结果 
                    stmt.execute();
                    if(stmt.getUpdateCount()>0)
                    {
                    	return true;
                    }
                    return false;
            } catch (SQLException e) { 
                    //log.error("#ERROR# :执行SQL语句出错，请检查！\n" + staticSql, e);
            		e.printStackTrace();
                    //throw new RuntimeException(e);
            		return false;
            }
        } 

        /** 
         * 在一个数据库连接上执行一批静态SQL语句 
         * 
         * @param conn        数据库连接 
         * @param sqlList 静态SQL语句字符串集合 
         */ 
        public static void executeBatchSQL(Connection conn, List<String> sqlList) { 
                try { 
                        //创建执行SQL的对象 
                        Statement stmt = conn.createStatement(); 
                        for (String sql : sqlList) { 
                                stmt.addBatch(sql); 
                        } 
                        //执行SQL，并获取返回结果 
                        stmt.executeBatch(); 
                } catch (SQLException e) { 
                        //log.error("#ERROR# :执行批量SQL语句出错，请检查！", e);
                		e.printStackTrace();
                } 
        } 

        public static void closeConnection(Connection conn) { 
                if (conn == null) return; 
                try { 
                        if (!conn.isClosed()) { 
                                //关闭数据库连接 
                                conn.close(); 
                        } 
                } catch (SQLException e) { 
                        //log.error("#ERROR# :关闭数据库连接发生异常，请检查！", e);
                		e.printStackTrace();
                        throw new RuntimeException(e); 
                } 
        } 
}