package dao;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class Config {

    private static Properties props = new Properties(); 
    
    static
    {
    	init();
    }
    
    private static void init()
    {
    	String dir = System.getProperty("config.dir");
        try {
        	  //InputStream in = DAO.class.getClassLoader().getResourceAsStream("config.properties");
        	
        	
        	File f = new File(dir+"/config.properties");  
        	InputStream in = new FileInputStream(f);  
			props.load(in);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
    }
    
    public static boolean getBoolean(String key)
    {
    	String value = get(key);
    	if(value.equals("1") || value.equals("true"))
    	{
    		return true;
    	}  	
        return false;
    }
    
    public static int getInt(String key)
    {
    	String value = get(key);
    	return Integer.parseInt(value);
    }
    
    public static String get(String key)
    {
        return props.getProperty(key); 
    }

}
