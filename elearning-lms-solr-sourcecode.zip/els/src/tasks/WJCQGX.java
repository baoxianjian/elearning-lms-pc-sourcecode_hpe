package tasks;

import dao.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;  
import java.util.TimerTask;  
import java.util.UUID;

import com.Log;
import com.Remote;
import com.Tika;
   
//文件抽取更新
public class WJCQGX extends MyTimerTask {
	
	public int  importType=1;
	
	public int getImportType() {
		return importType;
	}

	public void setImportType(int importType) {
		this.importType = importType;
	}

	public static final int IMPORT_TYPE_FULL=1; //全量导入
	public static final int IMPORT_TYPE_DELTA=2; //增量导入
  
	public static int counter=0;
    
	@Override  
    public void run() 
    {
    	//UUID.randomUUID();
    	
    	Connection c = DAO.getConnection();
    	String sql=null;
    	ArrayList<HashMap> al=null;
    	String whereStr="WHERE is_deleted='0'";
    	
    	switch(importType)
    	{
    		//全量
	    	case IMPORT_TYPE_FULL:
	    	{
	    		
	    		break;
	    	}
	    	//增量
	    	case IMPORT_TYPE_DELTA:
	    	{
	        	//得到上次索引时间
	        	sql="select unix_timestamp(key_value) AS key_value from eln_sh_task_time WHERE key_name='file.add.last_index_time'";
	        	al= DAO.executeQuery(c, sql);
	        	HashMap hm=al.get(0);
	        	String lastIndexTime=hm.get("key_value").toString();
	        	
	        	whereStr+=" AND f.updated_at > "+lastIndexTime;
	        	//
	        	
	    		break;
	    	}
	    	default:
	    	{
	    		System.out.println("please specify importType.");
	    		return;
	    	}
    	}
    	
    	//查询出文件信息，进行解析
    	sql="select f.kid,f.file_path,f.file_dir,f.file_extension from eln_ln_files f "+whereStr;
    	al = DAO.executeQuery(c, sql);
    	DAO.closeConnection(c);

    	HashMap row=null;
    	String parseFilePath=null;
    	
    	int length=al.size();
    	for(int i=0;i<length;i++)
    	{
    		row=al.get(i);
    		
    		//System.out.println(row.get("file_path").toString());
    		
    		//普通文件指定地址
    		parseFilePath=row.get("file_path").toString();
    		
    		//压缩包指定目录
    		if(row.get("file_extension").equals("zip"))
    		{
    			parseFilePath=row.get("file_dir").toString();
    		}
    		
    		
    		if(Config.get("file.base.dir").lastIndexOf("/upload")>0)
    		{
    			parseFilePath=parseFilePath.replaceAll("^/upload", "");
    		}

    		parseFilePath=Config.get("file.base.dir")+parseFilePath;

    		ArrayList fileInfoList= Tika.parseFile(parseFilePath);
    		
    		//一对多
    		saveFileInfo(row,fileInfoList);
    	}
    	
    }
  
    private void saveFileInfo(HashMap row,ArrayList<HashMap> fileInfoList)
    {
    	String sql=null;
    	long NOW=System.currentTimeMillis()/1000;
    	
    	HashMap hm=null;
    	String args[]=null;
    	int count=fileInfoList.size();
    	
    	Connection c = DAO.getConnection("DBPool2");
		DAO.executeSQL(c, "UPDATE eln_sh_file_info set is_deleted='1' WHERE file_id='"+row.get("kid")+"'");
		ArrayList result=DAO.executeQuery(c, "select kid from eln_sh_file_info where file_id='"+row.get("kid")+"'");
		DAO.closeConnection(c);
		
    	int fiCount =result.size(); //file_info_count
		
    	for(int i=0;i<count;i++)
    	{
    		hm=fileInfoList.get(i);
    		
    		//之前有kid
    		if(i<fiCount)
    		{
	    		//更新
	    		sql="UPDATE eln_sh_file_info SET file_title=?, file_content=?,updated_by=?,updated_at=?, is_deleted=? WHERE kid=?";
	    		args=new String[6];
	    		args[0]=hm.get("title").toString();
	    		args[1]=hm.get("content").toString();
	    		args[2]="OTHER";
	    		args[3]=NOW+"";
	    		args[4]="0";
	    		args[5]=((HashMap)result.get(i)).get("kid").toString();
	    		
    		}
	    	else
	    	{
	    		//插入
	    		sql="INSERT INTO eln_sh_file_info(kid,file_id,file_title,file_content,created_by,created_at)"
	    			+"VALUES(?,?,?,?,?,?)";
	    		args=new String[6];
	    		args[0]=UUID.randomUUID().toString();
	    		args[1]=row.get("kid").toString();
	    		args[2]=hm.get("title").toString();
				args[3]=hm.get("content").toString();
				args[4]="OTHER";
				args[5]=NOW+"";
	    	}


	    	System.out.println(sql+"  "+args[0]);
	    	
	    	c = DAO.getConnection("DBPool2");
	    	DAO.executeSQL(c, sql,args);
    		DAO.closeConnection(c);
    	}
    	
    	c = DAO.getConnection();
    	//更新上次索引时间
    	sql="UPDATE eln_sh_task_time SET key_value=current_timestamp,updated_at=unix_timestamp() WHERE key_name='file.add.last_index_time'";
    	DAO.executeSQL(c, sql);
		DAO.closeConnection(c);
    	
    }
    

    
}  