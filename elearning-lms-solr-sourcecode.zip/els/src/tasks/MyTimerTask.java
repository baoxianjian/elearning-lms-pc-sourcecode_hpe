package tasks;

import java.util.TimerTask;

public abstract class MyTimerTask extends TimerTask {
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDir() {
		return dir;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}
	public String getFn() {
		return fn;
	}
	public void setFn(String fn) {
		this.fn = fn;
	}
	public int getDirCapacity() {
		return dirCapacity;
	}
	public void setDirCapacity(String dirCapacity) {
		this.dirCapacity = Integer.parseInt(dirCapacity);
	}
	public String getCacheTime() {
		return cacheTime;
	}
	public void setCacheTime(String cacheTime) {
		this.cacheTime = cacheTime;
	}
	
	public String url;
	public String dir;
	public String fn;
	public int dirCapacity;
	public String cacheTime;
	
	
}
