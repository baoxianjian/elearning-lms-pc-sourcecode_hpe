package tasks;

import dao.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;  
import java.util.TimerTask;  

import com.Log;
import com.Remote;
   
  
public class SOLRGX extends MyTimerTask {  
  
	public static int counter=0;
    @Override  
    public void run() 
    {
    	//如果关闭了自动更新,则直接返回
    	if(!SolrConfig.getUpdateAuto())
    	{
    		return;
    	}

    	//需要触发的增量更新地址列表
    	String[] urls = SolrConfig.getDeltaImportUrls();
    	
    	//请求间隔
    	int threadInterval = SolrConfig.getThreadInterval();
    	
    	for(int i=0;i<urls.length;i++)
    	{
    		if(urls[i]!=null)
    		{
    			url=urls[i];
    			Remote.doGet(url);
    			Log.add("request url:"+url);
    			try {
					Thread.sleep(threadInterval*1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					Log.add(e.getMessage());
				}
    		}
    	}
    }
  
}