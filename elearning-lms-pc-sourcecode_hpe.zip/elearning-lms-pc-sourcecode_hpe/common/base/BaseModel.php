<?php

namespace common\base;

use Yii;
use yii\base\Model;

/**
 * Site controller
 */
class BaseModel extends Model
{
}
