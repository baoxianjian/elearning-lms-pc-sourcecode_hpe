<?php
namespace app\common;
/**
 * 用于api模块的常量
 */
class C{
 const IsDebug=true; //是否开发调试
	
}