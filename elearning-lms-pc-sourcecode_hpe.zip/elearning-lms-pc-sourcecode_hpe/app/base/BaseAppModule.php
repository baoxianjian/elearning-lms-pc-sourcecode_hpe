<?php

namespace app\base;

use Yii;
use common\base\BaseModule;

class BaseBackModule extends BaseModule
{
}