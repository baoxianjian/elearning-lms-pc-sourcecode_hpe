<?php

namespace app\base;

use Yii;
use common\base\BaseModel;

class BaseBackModel extends BaseModel
{
}