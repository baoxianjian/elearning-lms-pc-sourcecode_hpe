<?php

namespace app\base;

use Yii;
use common\base\BaseAction;

class BaseAppAction extends BaseAction
{
}

