<?php

namespace app\base;

use common\base\BaseActiveRecord;
use Yii;

class BaseAppActiveRecord extends BaseActiveRecord
{
}