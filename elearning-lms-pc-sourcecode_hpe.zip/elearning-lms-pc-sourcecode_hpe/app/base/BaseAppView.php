<?php

namespace app\base;

use Yii;
use common\base\BaseView;
use yii\helpers\Html;

class BaseAppView extends BaseView
{
	private $labelWidth='120px';


}
