<?php
/**
 * Created by PhpStorm.
 * User: TangMingQiang
 * Date: 3/8/15
 * Time: 2:41 PM
 */
use yii\helpers\Html;

?>
<?= $content ?>
