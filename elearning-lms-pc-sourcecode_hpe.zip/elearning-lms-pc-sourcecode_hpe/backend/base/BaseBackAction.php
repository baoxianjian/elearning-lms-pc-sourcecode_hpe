<?php

namespace backend\base;

use Yii;
use common\base\BaseAction;

class BaseBackAction extends BaseAction
{
}

