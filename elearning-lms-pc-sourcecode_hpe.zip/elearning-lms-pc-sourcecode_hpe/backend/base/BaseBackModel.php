<?php

namespace backend\base;

use Yii;
use common\base\BaseModel;

class BaseBackModel extends BaseModel
{
}