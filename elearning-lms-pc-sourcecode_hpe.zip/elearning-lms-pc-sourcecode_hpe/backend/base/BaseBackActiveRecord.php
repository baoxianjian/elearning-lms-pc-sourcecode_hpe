<?php

namespace backend\base;

use common\base\BaseActiveRecord;
use Yii;

class BaseBackActiveRecord extends BaseActiveRecord
{
}