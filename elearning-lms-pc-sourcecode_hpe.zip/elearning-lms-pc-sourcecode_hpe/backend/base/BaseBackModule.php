<?php

namespace backend\base;

use Yii;
use common\base\BaseModule;

class BaseBackModule extends BaseModule
{
}