<?php

namespace backend\modules\filemanager;


use yii\base\Module;
class FileManagerModule extends Module
{
    public $controllerNamespace = 'backend\modules\filemanager\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
