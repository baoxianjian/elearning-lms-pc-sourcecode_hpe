<?
use yii\helpers\Html;
?>



<!-- Custom CSS -->
<!--<link href="../dist/css/sb-admin-2.css" rel="stylesheet">-->
<?=Html::cssFile('/static/backend/css/sb-admin-2.css')?>

<?=Html::cssFile('/static/backend/css/miniNav.css')?>


<?=Html::jsFile('/static/backend/js/controlPanel.js')?>

<?=Html::cssFile('/static/common/css/common.css')?>
<?=Html::jsFile('/static/common/js/common.js')?>



<?//=Html::jsFile('/static/backend/js/jquery.form.js')?>

<?//=Html::jsFile('/vendor/bower/jquery/dist/jquery.min.js')?>

<?//=Html::jsFile('/vendor/bower/bootstrap/dist/js/bootstrap.min.js')?>

<!-- Metis Menu Plugin JavaScript -->
<?=Html::jsFile('/vendor/bower/metisMenu/dist/metisMenu.min.js')?>

<!-- Custom Theme JavaScript -->
<?=Html::jsFile('/vendor/bower/startbootstrap-sb-admin-2/dist/js/sb-admin-2.js')?>

<?=Html::cssFile('/static/common/css/animate.css')?>
<?=Html::jsFile('/components/noty/packaged/jquery.noty.packaged.min.js')?>
