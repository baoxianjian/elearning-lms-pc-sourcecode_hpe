<?php
namespace api\models;
use yii\base\Model;
use Yii;

class TagInfo extends BaseModel {
	public $tag_value;              //话题
}