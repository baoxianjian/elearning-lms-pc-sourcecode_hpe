<?php
$rootDir = __DIR__ . '/../..';

require_once($rootDir . '/common/crypt/MessageCrypt.php');
require_once($rootDir . '/common/crypt/SHA1.php');
require_once($rootDir . '/components/mpdf60/mpdf.php');

?>