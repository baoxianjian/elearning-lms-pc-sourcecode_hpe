<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;


?>
欢迎使用<?= Yii::t('system','api_name')?>。具体接口文档，请向系统管理员索取。