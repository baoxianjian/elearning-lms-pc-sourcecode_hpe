<?php

namespace api\modules\v2;

use yii\base\Module;

class ApiModule extends Module
{

    public function init()
    {
        parent::init();
        // custom initialization code goes here
    }
}
